<template>
  <div id="app">
    <Main/>
  </div>
</template>

<script>
import Main from './components/Main.vue'

export default {
  name: 'App',
  components: {
    Main
  }
}
</script>

<style>
.is-family-monospace {
  font-family: 'Courier New', Courier, monospace;
}
</style>
